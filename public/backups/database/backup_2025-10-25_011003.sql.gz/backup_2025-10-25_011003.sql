-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: qr_attendance
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `qr_attendance`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `qr_attendance` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `qr_attendance`;

--
-- Table structure for table `academic_years`
--

DROP TABLE IF EXISTS `academic_years`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `academic_years` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_current` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_year` (`year`),
  KEY `idx_is_current` (`is_current`),
  KEY `idx_academic_current` (`is_current`,`year`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_years`
--

LOCK TABLES `academic_years` WRITE;
/*!40000 ALTER TABLE `academic_years` DISABLE KEYS */;
INSERT INTO `academic_years` VALUES (1,2025,'2024-09-01','2025-08-31',1,'2025-10-11 11:16:08');
/*!40000 ALTER TABLE `academic_years` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` varchar(50) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `timestamp` datetime NOT NULL,
  `status` enum('Check-in','Present','Absent') NOT NULL,
  `check_in_time` datetime DEFAULT NULL,
  `check_out_time` datetime DEFAULT NULL,
  `session_duration` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `admission_year` int(11) DEFAULT NULL,
  `current_year` int(11) DEFAULT NULL,
  `shift` varchar(20) DEFAULT NULL,
  `program` varchar(10) DEFAULT NULL,
  `is_graduated` tinyint(1) DEFAULT 0,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_attendance_student_timestamp` (`student_id`,`timestamp`),
  KEY `idx_check_in_time` (`check_in_time`),
  KEY `idx_check_out_time` (`check_out_time`),
  KEY `idx_attendance_program_shift` (`program`,`shift`,`timestamp`),
  KEY `idx_attendance_checkin_checkout` (`student_id`,`check_in_time`,`check_out_time`),
  KEY `idx_attendance_years` (`admission_year`,`current_year`),
  KEY `idx_status` (`status`),
  KEY `idx_attendance_timestamp_status` (`timestamp`,`status`),
  KEY `idx_attendance_student_date_status` (`student_id`,`timestamp`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES (28,'25-SWT-331','Sample Student','2025-10-25 00:36:18','Present','2025-10-25 00:36:18','2025-10-25 00:37:15',1,'2025-10-24 19:36:18','2025-10-24 19:37:15',2025,2,'Morning','SWT',0,''),(29,'25-SWT-330','Sample Student 1','2025-10-25 00:38:30','Check-in','2025-10-25 00:38:30',NULL,NULL,'2025-10-24 19:38:30','2025-10-24 19:38:30',2025,2,'Morning','SWT',0,''),(30,'25-CIT-332','Sample Student 3','2025-10-25 00:39:00','Absent',NULL,NULL,NULL,'2025-10-24 19:39:14','2025-10-24 19:39:14',NULL,NULL,'morning',NULL,0,'Auto-marked absent by system');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `action` varchar(100) NOT NULL,
  `user_type` enum('admin','student') NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `details` text DEFAULT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  PRIMARY KEY (`id`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_action` (`action`),
  KEY `idx_user` (`user_type`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,'2025-10-24 20:48:53','database_backup','admin','system','unknown','unknown','Automatic backup created: backup_2025-10-24_204851.sql.gz','null');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `check_in_sessions`
--

DROP TABLE IF EXISTS `check_in_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_in_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` varchar(50) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `check_in_time` datetime NOT NULL,
  `last_activity` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_active_session` (`student_id`,`is_active`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_check_in_time` (`check_in_time`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_checkin_active` (`is_active`,`student_id`,`check_in_time`),
  KEY `idx_checkin_activity` (`last_activity`,`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `check_in_sessions`
--

LOCK TABLES `check_in_sessions` WRITE;
/*!40000 ALTER TABLE `check_in_sessions` DISABLE KEYS */;
INSERT INTO `check_in_sessions` VALUES (12,'24-ESWT-01','Anique','2025-10-24 17:18:45','2025-10-24 17:18:45',1,'2025-10-24 12:18:45'),(16,'25-SWT-330','Sample Student 1','2025-10-25 00:38:30','2025-10-25 00:38:30',1,'2025-10-24 19:38:30');
/*!40000 ALTER TABLE `check_in_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_verifications`
--

DROP TABLE IF EXISTS `email_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_verifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `verification_code` varchar(6) NOT NULL,
  `purpose` enum('password_reset','email_change') NOT NULL,
  `expires_at` datetime NOT NULL,
  `is_used` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_code` (`verification_code`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_verifications`
--

LOCK TABLES `email_verifications` WRITE;
/*!40000 ALTER TABLE `email_verifications` DISABLE KEYS */;
INSERT INTO `email_verifications` VALUES (19,'24-ESWT-01','aniqueali000@gmail.com','587253','password_reset','2025-10-18 13:58:00',1,'2025-10-18 08:43:00'),(20,'24-ESWT-01','aniqueali000@gmail.com','589890','password_reset','2025-10-18 13:59:44',0,'2025-10-18 08:44:44'),(21,'24-ESWT-01','aniqueali000@gmail.com','563468','password_reset','2025-10-18 14:02:52',1,'2025-10-18 08:47:52'),(22,'24-ESWT-01','aniqueali000@gmail.com','664199','password_reset','2025-10-18 16:55:53',0,'2025-10-18 11:40:53'),(23,'25-SWT-330','student1_1761307066330@college.edu','330806','password_reset','2025-10-24 17:15:24',0,'2025-10-24 12:00:24'),(24,'25-SWT-330','aniqueali28@gmail.com','314397','password_reset','2025-10-24 17:16:33',1,'2025-10-24 12:01:33'),(25,'25-SWT-331','student2_1761307066330@college.edu','900906','password_reset','2025-10-25 00:52:35',0,'2025-10-24 19:37:35');
/*!40000 ALTER TABLE `email_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_logs`
--

DROP TABLE IF EXISTS `import_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `import_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `import_type` varchar(50) NOT NULL,
  `total_records` int(11) NOT NULL,
  `successful_records` int(11) NOT NULL,
  `failed_records` int(11) NOT NULL,
  `error_details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_import_type_date` (`import_type`,`created_at`),
  KEY `idx_import_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_logs`
--

LOCK TABLES `import_logs` WRITE;
/*!40000 ALTER TABLE `import_logs` DISABLE KEYS */;
INSERT INTO `import_logs` VALUES (1,'student_import',4,4,0,'[]','2025-10-13 06:09:17'),(2,'student_import',4,4,0,'[]','2025-10-13 07:07:44'),(3,'student_import',4,4,0,'[]','2025-10-13 07:08:19'),(4,'student_import',4,4,0,'[]','2025-10-13 07:27:36'),(5,'student_import',4,4,0,'[]','2025-10-15 20:53:30'),(6,'student_import',4,4,0,'[]','2025-10-16 08:28:34'),(7,'student_import',4,4,0,'[]','2025-10-16 08:43:15'),(8,'student_import',4,4,0,'[]','2025-10-24 11:58:15'),(9,'student_import',4,0,4,'[{\"success\":false,\"row\":1,\"student_id\":\"25-SWT-330\",\"error\":\"SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'25-SWT-330\' for key \'student_id\'\"},{\"success\":false,\"row\":2,\"student_id\":\"25-SWT-331\",\"error\":\"SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'25-SWT-331\' for key \'student_id\'\"},{\"success\":false,\"row\":3,\"student_id\":\"25-CIT-332\",\"error\":\"SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'25-CIT-332\' for key \'student_id\'\"},{\"success\":false,\"row\":4,\"student_id\":\"25-CIT-333\",\"error\":\"SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'25-CIT-333\' for key \'student_id\'\"}]','2025-10-24 11:58:21'),(10,'student_import',4,0,4,'[{\"success\":false,\"row\":1,\"student_id\":\"25-SWT-330\",\"error\":\"SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'25-SWT-330\' for key \'student_id\'\"},{\"success\":false,\"row\":2,\"student_id\":\"25-SWT-331\",\"error\":\"SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'25-SWT-331\' for key \'student_id\'\"},{\"success\":false,\"row\":3,\"student_id\":\"25-CIT-332\",\"error\":\"SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'25-CIT-332\' for key \'student_id\'\"},{\"success\":false,\"row\":4,\"student_id\":\"25-CIT-333\",\"error\":\"SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'25-CIT-333\' for key \'student_id\'\"}]','2025-10-24 11:58:27');
/*!40000 ALTER TABLE `import_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `used_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_email` (`email`),
  KEY `idx_token` (`token`),
  KEY `idx_expires_at` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES (1,'aniqueali000@gmail.com','1c510ec757adbd5f0637b9889d71c0afef3e82ec0d7318c74e687714e7424a80','2025-10-24 17:52:19','2025-10-24 11:52:19',NULL);
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `program_stats`
--

DROP TABLE IF EXISTS `program_stats`;
/*!50001 DROP VIEW IF EXISTS `program_stats`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `program_stats` AS SELECT
 1 AS `id`,
  1 AS `code`,
  1 AS `name`,
  1 AS `is_active`,
  1 AS `total_students`,
  1 AS `total_sections`,
  1 AS `total_capacity`,
  1 AS `avg_attendance` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `programs`
--

DROP TABLE IF EXISTS `programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `duration_years` int(11) DEFAULT 4,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_code` (`code`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_programs_active_name` (`is_active`,`name`(50))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programs`
--

LOCK TABLES `programs` WRITE;
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
INSERT INTO `programs` VALUES (1,'SWT','Software Technology','D.A.E',3,1,'2025-10-11 11:16:08','2025-10-11 12:00:56'),(4,'CIT','Computer Information Technology','D.A.E',3,1,'2025-10-11 11:16:08','2025-10-14 22:08:59'),(23,'ESWT','Software Technology Evening','D.A.E',3,1,'2025-10-13 07:42:13','2025-10-16 05:25:38'),(24,'ECIT','Computer Information Technology Evening','D.A.E',3,1,'2025-10-13 07:42:27','2025-10-16 05:25:43');
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qr_codes`
--

DROP TABLE IF EXISTS `qr_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qr_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` varchar(50) NOT NULL,
  `qr_data` text NOT NULL,
  `qr_image_path` varchar(255) DEFAULT NULL,
  `generated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_qr_student_active` (`student_id`,`is_active`,`generated_at`),
  KEY `idx_qr_generated` (`generated_at`),
  CONSTRAINT `qr_codes_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qr_codes`
--

LOCK TABLES `qr_codes` WRITE;
/*!40000 ALTER TABLE `qr_codes` DISABLE KEYS */;
INSERT INTO `qr_codes` VALUES (35,'22-SWT-01','22-SWT-01','C:\\xampp\\htdocs\\qr_attendance\\public/assets/img/qr_codes/qr_22-SWT-01_1760186456.png','2025-10-11 12:40:56',1,10),(36,'22-SWT-02','22-SWT-02','C:\\xampp\\htdocs\\qr_attendance\\public/assets/img/qr_codes/qr_22-SWT-02_1760210056.png','2025-10-11 19:14:16',1,10),(37,'22-ESWT-02','22-ESWT-02','C:\\xampp\\htdocs\\qr_attendance\\public/assets/img/qr_codes/qr_22-ESWT-02_1760217877.png','2025-10-11 21:24:37',1,10),(38,'25-SWT-26','25-SWT-26','C:\\xampp\\htdocs\\qr_attendance\\public/assets/img/qr_codes/qr_25-SWT-26_1760429175.png','2025-10-14 08:06:15',1,10),(39,'25-SWT-03','25-SWT-03','C:\\xampp\\htdocs\\qr_attendance\\public/assets/img/qr_codes/qr_25-SWT-03_1760429238.png','2025-10-14 08:07:18',1,10),(40,'24-ESWT-01','24-ESWT-01','C:\\xampp\\htdocs\\qr_attendance\\public/assets/img/qr_codes/qr_24-ESWT-01_1760444369.png','2025-10-14 12:19:29',1,10),(75,'25-SWT-595','{\"student_id\":\"25-SWT-595\",\"name\":\"Sample Student 1\",\"timestamp\":1760605851,\"type\":\"attendance\"}','','2025-10-16 09:10:51',1,10),(76,'25-SWT-596','{\"student_id\":\"25-SWT-596\",\"name\":\"Sample Student 2\",\"timestamp\":1760605851,\"type\":\"attendance\"}','','2025-10-16 09:10:51',1,10),(77,'25-CIT-597','{\"student_id\":\"25-CIT-597\",\"name\":\"Sample Student 3\",\"timestamp\":1760605851,\"type\":\"attendance\"}','','2025-10-16 09:10:51',1,10),(78,'25-CIT-598','{\"student_id\":\"25-CIT-598\",\"name\":\"Sample Student 4\",\"timestamp\":1760605851,\"type\":\"attendance\"}','','2025-10-16 09:10:51',1,10),(79,'25-SWT-599','{\"student_id\":\"25-SWT-599\",\"name\":\"Sample Student 1\",\"timestamp\":1760605851,\"type\":\"attendance\"}','','2025-10-16 09:10:51',1,10),(80,'25-SWT-600','{\"student_id\":\"25-SWT-600\",\"name\":\"Sample Student 2\",\"timestamp\":1760605851,\"type\":\"attendance\"}','','2025-10-16 09:10:51',1,10),(81,'25-CIT-601','{\"student_id\":\"25-CIT-601\",\"name\":\"Sample Student 3\",\"timestamp\":1760605851,\"type\":\"attendance\"}','','2025-10-16 09:10:51',1,10),(82,'25-CIT-602','{\"student_id\":\"25-CIT-602\",\"name\":\"Sample Student 4\",\"timestamp\":1760605851,\"type\":\"attendance\"}','','2025-10-16 09:10:51',1,10),(83,'25-SWT-330','{\"student_id\":\"25-SWT-330\",\"name\":\"Sample Student 1\",\"timestamp\":1761318293,\"type\":\"attendance\"}','','2025-10-24 15:04:53',1,10),(84,'25-SWT-331','{\"student_id\":\"25-SWT-331\",\"name\":\"Sample Student 2\",\"timestamp\":1761318293,\"type\":\"attendance\"}','','2025-10-24 15:04:53',1,10),(85,'25-CIT-332','{\"student_id\":\"25-CIT-332\",\"name\":\"Sample Student 3\",\"timestamp\":1761318293,\"type\":\"attendance\"}','','2025-10-24 15:04:53',1,10),(86,'25-CIT-333','{\"student_id\":\"25-CIT-333\",\"name\":\"Sample Student 4\",\"timestamp\":1761318293,\"type\":\"attendance\"}','','2025-10-24 15:04:53',1,10);
/*!40000 ALTER TABLE `qr_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `section_stats`
--

DROP TABLE IF EXISTS `section_stats`;
/*!50001 DROP VIEW IF EXISTS `section_stats`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `section_stats` AS SELECT
 1 AS `id`,
  1 AS `section_name`,
  1 AS `program_code`,
  1 AS `program_name`,
  1 AS `year_level`,
  1 AS `shift`,
  1 AS `capacity`,
  1 AS `current_students`,
  1 AS `capacity_utilization` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_id` int(11) NOT NULL,
  `year_level` enum('1st','2nd','3rd') NOT NULL,
  `section_name` varchar(10) NOT NULL,
  `shift` enum('Morning','Evening') NOT NULL,
  `capacity` int(11) DEFAULT 40,
  `current_students` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_section` (`program_id`,`year_level`,`section_name`,`shift`),
  KEY `idx_program_year` (`program_id`,`year_level`),
  KEY `idx_shift` (`shift`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_sections_filter` (`program_id`,`year_level`,`shift`,`is_active`),
  KEY `idx_sections_capacity` (`program_id`,`is_active`,`capacity`,`current_students`),
  KEY `idx_sections_year_shift` (`year_level`,`shift`,`is_active`),
  CONSTRAINT `sections_ibfk_1` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,1,'1st','A','Morning',41,1,1,'2025-10-11 22:15:27','2025-10-16 09:31:34'),(2,1,'1st','B','Morning',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(3,1,'1st','A','Evening',41,0,1,'2025-10-11 22:15:27','2025-10-13 07:57:56'),(4,1,'1st','B','Evening',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(5,1,'2nd','A','Morning',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(6,1,'2nd','B','Morning',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(7,1,'2nd','A','Evening',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(8,1,'2nd','B','Evening',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(9,1,'3rd','A','Morning',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(10,1,'3rd','B','Morning',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(11,1,'3rd','A','Evening',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(12,1,'3rd','B','Evening',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(13,4,'1st','A','Morning',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(14,4,'1st','B','Morning',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(15,4,'1st','A','Evening',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(16,4,'1st','B','Evening',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(17,4,'2nd','A','Morning',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(18,4,'2nd','B','Morning',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(19,4,'2nd','A','Evening',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(20,4,'2nd','B','Evening',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(21,4,'3rd','A','Morning',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(22,4,'3rd','B','Morning',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(23,4,'3rd','A','Evening',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(24,4,'3rd','B','Evening',40,0,1,'2025-10-11 22:15:27','2025-10-11 23:33:31'),(25,4,'1st','C','Evening',40,0,1,'2025-10-14 20:49:08','2025-10-14 20:49:08');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(128) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text DEFAULT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_last_activity` (`last_activity`),
  KEY `idx_sessions_cleanup` (`last_activity`,`user_id`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('06c342a76f4a19b65c3fcca3604de4f189cfdb35cf3a07219a37df7399a9ab56',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-18 12:48:51','2025-10-18 11:48:56'),('1009eaa0ba3f893abc280f5c2dfa6a95a216dcca221d579f4f500f48681dfd94',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-12 22:55:35','2025-10-12 22:38:33'),('1342831de47f3f8ba1f86ab3ea65e69b6e6835417fb4c1d878621431954a4bc2',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-23 19:37:44','2025-10-23 18:15:54'),('20a4d33533a9db29f3087eb8da315e8d56f25e99ba49fdee4228dbbc679c6203',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-12 15:29:23','2025-10-12 15:28:53'),('2e26cd1f54a55dd4bad475cc751bb7fa10fd10191ba107a00f19515fcaec6971',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-12 22:11:03','2025-10-12 22:11:03'),('35fe7dc19cd7872696b8c02b717750f38d3ccd8b0bb4ecd07bfde33990fb78e4',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-13 11:06:22','2025-10-13 10:36:07'),('4f18301bf687475ca144da8eab48e993341f3e747ac0c945164ab64ad13bd09f',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-11 12:49:36','2025-10-11 12:23:26'),('546a2ca0b5167208898d8aadeb96d136536e15dffec974224a1acc54bd286cb7',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-14 08:43:51','2025-10-14 07:43:44'),('5947eeafdd104f8a5202330f048b5513057c356de24abcf0f3c25d5f6736af19',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-13 19:57:58','2025-10-13 19:00:00'),('5cda76defde8c46ac5d6d3ba27779450fe9ed1b78ce4b24815dcef14b302a718',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-24 10:29:47','2025-10-24 10:29:35'),('60d52610d3e9bf09293a779847cc491e3f803faf8976f17c2ddc2732c1ab1705',10,'unknown','unknown',NULL,'2025-10-12 22:36:02','2025-10-12 22:36:02'),('677e95ccfcf14eef4c79921fa151f05eee95b7208e1c6173154cf77a73212256',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-13 19:25:27','2025-10-13 19:25:22'),('75f10bddd011db5c8ae5255ffc0d82471e84158cc8ebab5a7637ed305d6ba0d2',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-24 19:53:54','2025-10-24 19:22:41'),('785e481c6f218a0f2f7f2aae4c7da9ae192e028fa9abf34d49516089384d374d',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-13 09:23:12','2025-10-13 07:56:42'),('7d496ba5331e080bb8a350c567398b747d88384635793edca9c9a0560d14648c',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-11 23:40:19','2025-10-11 22:11:08'),('83f64654cb1671443ef02329392d1ac6926e5beeb8f0e6a9ee4f975684055919',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-18 11:48:42','2025-10-18 11:37:20'),('89b6a2dbf3afaf56b7047b19c6461dbe65767e492daefe00cc7a3727a73da3dc',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-13 21:56:04','2025-10-13 19:59:02'),('944ad316e85cd701a0b93a965c668c229a27dd8aea7751b4c94e4aaf455fc733',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-16 00:38:28','2025-10-15 21:31:29'),('99465cca2614829aedf0479097b73652ea741c8f8185c7290a30b2bdfcb7ae36',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-12 22:11:00','2025-10-12 22:11:00'),('9d98c32cf1e5d2dcb7c6a865b931812397821adec81e9b4600401185575ad7e2',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-13 21:31:28','2025-10-13 19:26:02'),('9dc581cbe33106df88412e23a3f1c8532a8864f112d94edd52515b38598b525a',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-12 20:40:16','2025-10-12 20:07:11'),('afbf18251a0cfc75f381db412b5fdae90e5fb2e1023575f9ec8b96969f9aba9b',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-16 09:32:29','2025-10-16 08:53:07'),('b88f3096ec9cd331741fd0c13aff83b608d6a6afca94f3c69176f1f836b57493',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',NULL,'2025-10-11 20:27:44','2025-10-11 20:27:43'),('bb98d3e9a016c08abbe7e6cd188ab51c802f2d9a7636c08d31500aedc73c2440',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-13 07:54:33','2025-10-13 05:54:36'),('c7afef596643451c00f0cd7f50fbeea2d8f85fea45d29ba89cad975c120acf3b',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-24 11:08:40','2025-10-24 11:08:37'),('dd302bfe01e2d09824d73a3d10eecb9c9694ba62a22711460917626c0788541a',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-11 21:21:27','2025-10-11 21:15:07'),('df4fb47ae33b880ee836f2ac518b530d5b1af1110bcf008f9f35a976e888d5da',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-12 21:37:48','2025-10-12 20:48:24'),('df8bba17c4d6f1fc0e30ada663c2d31e7340cd228d3727465726a0ecd48ccbaf',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-12 20:07:03','2025-10-12 19:35:34'),('e316e2f95ee65a46bbeae9961e575d5b0970827f8b7b5b930b0f56b843b593e8',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-24 11:58:29','2025-10-24 11:25:03'),('ed6362dbaa1d5b7ffb5cc0928c29206b11c8338d1826932f1024c4d9b17a0d97',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-23 20:17:07','2025-10-23 19:38:27'),('f0c763b4a0a63fa47ad976095f96dc41335c663996458669cb25116e6dfc6384',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-11 12:22:14','2025-10-11 12:04:16'),('f2fda114688050d36908dc8e7a2a7ca6ae5bc83d357c43a0f409469abf4430dd',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-12 22:10:46','2025-10-12 22:10:31'),('f51b931131ef008c1d59dd43bb68a4d5369b05ef96942a33cb1942fb38a98f75',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-24 10:29:02','2025-10-24 10:28:14'),('f8dc1addbb044e8f2ccf59376ef84b237f9e8c6db7207766236e16d1f1325540',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-11 21:31:42','2025-10-11 21:27:24'),('f94a0a16f0b071c77edb77d08401c5373f61f46848a19676caedcf3a1134a146',10,'unknown','unknown',NULL,'2025-10-12 22:37:59','2025-10-12 22:37:59'),('fb2db220e3a9cf7a6b04ae7bbc7358263e8364b904b489da7a9a96c365c71787',10,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',NULL,'2025-10-12 22:14:28','2025-10-12 22:11:04'),('test_admin_session_1760788045',10,NULL,NULL,NULL,'2025-10-18 11:47:25','2025-10-18 11:47:25');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_timings`
--

DROP TABLE IF EXISTS `shift_timings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shift_timings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_name` enum('Morning','Evening') NOT NULL,
  `checkin_start` time NOT NULL,
  `checkin_end` time NOT NULL,
  `class_end` time NOT NULL,
  `minimum_duration_minutes` int(11) DEFAULT 120,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_shift` (`shift_name`),
  KEY `idx_shift_name` (`shift_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_timings`
--

LOCK TABLES `shift_timings` WRITE;
/*!40000 ALTER TABLE `shift_timings` DISABLE KEYS */;
INSERT INTO `shift_timings` VALUES (1,'Morning','09:00:00','11:00:00','13:40:00',120,1,'2025-10-11 11:16:08','2025-10-11 11:16:08'),(2,'Evening','15:00:00','16:00:00','18:00:00',120,1,'2025-10-11 11:16:08','2025-10-11 11:16:08');
/*!40000 ALTER TABLE `shift_timings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `student_stats`
--

DROP TABLE IF EXISTS `student_stats`;
/*!50001 DROP VIEW IF EXISTS `student_stats`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `student_stats` AS SELECT
 1 AS `student_id`,
  1 AS `name`,
  1 AS `email`,
  1 AS `phone`,
  1 AS `program`,
  1 AS `shift`,
  1 AS `year_level`,
  1 AS `section`,
  1 AS `program_name`,
  1 AS `capacity`,
  1 AS `total_attendance`,
  1 AS `present_count`,
  1 AS `attendance_percentage` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` varchar(50) NOT NULL,
  `roll_number` varchar(20) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `admission_year` int(11) DEFAULT NULL,
  `current_year` int(11) DEFAULT 1,
  `shift` enum('Morning','Evening') DEFAULT 'Morning',
  `program` varchar(50) DEFAULT NULL,
  `last_year_update` date DEFAULT NULL,
  `is_graduated` tinyint(1) DEFAULT 0,
  `year_level` enum('1st','2nd','3rd','4th') DEFAULT NULL,
  `section` varchar(10) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `roll_prefix` varchar(20) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `attendance_percentage` decimal(5,2) DEFAULT 0.00,
  `username` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `student_id` (`student_id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_students_admission_year` (`admission_year`),
  KEY `idx_students_current_year` (`current_year`),
  KEY `idx_students_shift` (`shift`),
  KEY `idx_students_program` (`program`),
  KEY `idx_students_is_graduated` (`is_graduated`),
  KEY `idx_program` (`program`),
  KEY `idx_shift` (`shift`),
  KEY `idx_year_level` (`year_level`),
  KEY `idx_section` (`section`),
  KEY `idx_admission_year` (`admission_year`),
  KEY `idx_section_id` (`section_id`),
  KEY `idx_students_program_shift_year` (`program`,`shift`,`year_level`),
  KEY `idx_last_year_update` (`last_year_update`),
  KEY `idx_roll_prefix` (`roll_prefix`),
  KEY `idx_students_section_active` (`section_id`,`is_active`,`year_level`),
  KEY `idx_students_name` (`name`(50)),
  KEY `idx_students_email` (`email`),
  KEY `idx_students_roll` (`roll_number`,`is_active`),
  CONSTRAINT `fk_students_section` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE SET NULL,
  CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (141,'24-ESWT-01','24-ESWT-01','Anique','aniqueali000@gmail.com','+923010020668','$argon2id$v=19$m=65536,t=4,p=3$VDc5S2FYWEtZSEwyUERpbQ$ZmEDaZyB7p0cu5BdFOaSKxoXwu+bNr787IboCIVpZ4M',NULL,1,'2025-10-16 05:57:41','2025-10-24 15:32:53',2024,3,'Evening','SWT',NULL,0,'3rd','A','24-ESWT-01_1760787661',NULL,NULL,0.00,'24-ESWT-01'),(150,'25-SWT-330','25-SWT-330','Sample Student 1','aniqueali28@gmail.com','923001234567','$argon2id$v=19$m=65536,t=4,p=3$Y1RaVXJqcWNqcnA1ZDVOQg$qMjXwh8spUfsZnYkaM2sOpjrc+N7JOxU3qeQtyJR990',NULL,1,'2025-10-24 11:58:11','2025-10-24 15:32:53',2025,2,'Morning','SWT',NULL,0,'2nd','A',NULL,'SWT',1,0.00,'25-SWT-330'),(151,'25-SWT-331','25-SWT-331','Sample Student','student2_1761307066330@college.edu','923007654321','$argon2id$v=19$m=65536,t=4,p=3$U3k3WThIWkl5R3ZLRzVtTA$AJBAabPU4PMQSrupxfVW/PW81S0cEweFUrHrsWoI9nQ',NULL,1,'2025-10-24 11:58:12','2025-10-24 19:33:34',2025,2,'Morning','SWT',NULL,0,'1st','A',NULL,'SWT',4,0.00,'25-SWT-331'),(152,'25-CIT-332','25-CIT-332','Sample Student 3','student3_1761307066330@college.edu','923009876543','25-CIT-332',NULL,1,'2025-10-24 11:58:14','2025-10-24 15:32:53',2025,2,'Morning','CIT',NULL,0,'2nd','A',NULL,'CIT',13,0.00,'25-CIT-332'),(153,'25-CIT-333','25-CIT-333','Sample Student 4','student4_1761307066330@college.edu','923001112233','25-CIT-333',NULL,1,'2025-10-24 11:58:15','2025-10-24 15:32:53',2025,2,'Evening','CIT',NULL,0,'2nd','B',NULL,'CIT',16,0.00,'25-CIT-333'),(162,'24-ESWT-02','24-ESWT-02','tesing','admin@gmail.com','+9230100220668','24-ESWT-02',NULL,1,'2025-10-24 15:31:27','2025-10-24 15:31:27',2024,1,'Evening','SWT',NULL,0,'2nd','A',NULL,NULL,NULL,0.00,'24-ESWT-02'),(163,'24-ESWT-03','24-ESWT-03','ges','adminff@gma.com','2312312111','24-ESWT-03',NULL,1,'2025-10-24 15:32:01','2025-10-24 15:32:01',2024,1,'Evening','SWT',NULL,0,'4th','A',NULL,NULL,NULL,0.00,'24-ESWT-03');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync_logs`
--

DROP TABLE IF EXISTS `sync_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sync_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sync_type` enum('push_to_web','pull_from_web','bidirectional') NOT NULL,
  `status` enum('success','failed','partial') NOT NULL,
  `records_processed` int(11) DEFAULT 0,
  `records_failed` int(11) DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `sync_duration` decimal(10,3) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sync_type` (`sync_type`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_sync_type_status` (`sync_type`,`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync_logs`
--

LOCK TABLES `sync_logs` WRITE;
/*!40000 ALTER TABLE `sync_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `sync_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  `setting_type` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `validation_rules` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`validation_rules`)),
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_setting_key` (`setting_key`),
  KEY `idx_category` (`category`),
  KEY `idx_settings_category_key` (`category`,`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1758 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'morning_checkin_start','00:00:00','time','shift_timings','Morning shift check-in start time','{\"required\":true,\"type\":\"time\"}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(2,'morning_checkin_end','00:39:00','time','shift_timings','Morning shift check-in end time','{\"required\":true,\"type\":\"time\"}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(3,'morning_checkout_start','00:00:00','time','shift_timings','Morning shift check-out start time','{\"required\":true,\"type\":\"time\"}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(4,'morning_checkout_end','04:00:00','time','shift_timings','Morning shift check-out end time','{\"required\":true,\"type\":\"time\"}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(5,'morning_class_end','04:00:00','time','shift_timings','Morning shift class end time','{\"required\":true,\"type\":\"time\"}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(6,'evening_checkin_start','09:00:00','time','shift_timings','Evening shift check-in start time','{\"required\":true,\"type\":\"time\"}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(7,'evening_checkin_end','18:00:00','time','shift_timings','Evening shift check-in end time','{\"required\":true,\"type\":\"time\"}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(8,'evening_checkout_start','09:00:00','time','shift_timings','Evening shift check-out start time','{\"required\":true,\"type\":\"time\"}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(9,'evening_checkout_end','18:00:00','time','shift_timings','Evening shift check-out end time','{\"required\":true,\"type\":\"time\"}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(10,'evening_class_end','18:00:00','time','shift_timings','Evening shift class end time','{\"required\":true,\"type\":\"time\"}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(11,'minimum_duration_minutes','130','integer','system_config','Minimum duration in minutes for attendance','{\"required\":true,\"min\":30,\"max\":480}','2025-10-16 09:31:42','admin','2025-10-12 00:09:58'),(12,'sync_interval_seconds','30','integer','system_config','Automatic sync interval in seconds','{\"required\":true,\"min\":10,\"max\":300}','2025-10-16 09:31:42','admin','2025-10-12 00:09:58'),(13,'timezone','Asia/Karachi','string','system_config','System timezone','{\"required\":true,\"options\":[\"Asia\\/Karachi\",\"UTC\",\"America\\/New_York\",\"Europe\\/London\"]}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(14,'academic_year_start_month','9','integer','system_config','Academic year start month (1-12)','{\"required\":true,\"min\":1,\"max\":12}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(15,'auto_absent_morning_hour','11','integer','system_config','Hour to mark morning shift absent (24h format)','{\"required\":true,\"min\":8,\"max\":16}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(16,'auto_absent_evening_hour','17','integer','system_config','Hour to mark evening shift absent (24h format)','{\"required\":true,\"min\":14,\"max\":20}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(17,'website_url','http://localhost/qr_attendance/public','url','integration','Base URL of the web application','{\"required\":true,\"type\":\"url\"}','2025-10-16 09:31:42','admin','2025-10-12 00:09:58'),(18,'api_endpoint_attendance','/api/api_attendance.php','string','integration','Attendance API endpoint','[]','2025-10-16 09:31:42','admin','2025-10-12 00:09:58'),(19,'api_endpoint_checkin','/api/checkin_api.php','string','integration','Check-in API endpoint','[]','2025-10-16 09:31:42','admin','2025-10-12 00:09:58'),(20,'api_endpoint_dashboard','/api/dashboard_api.php','string','integration','Dashboard API endpoint','[]','2025-10-16 09:31:42','admin','2025-10-12 00:09:58'),(21,'api_key','attendance_2025_xyz789_secure','string','integration','API authentication key','{\"required\":true,\"min_length\":10}','2025-10-16 09:31:42','admin','2025-10-12 00:09:58'),(22,'api_timeout_seconds','30','integer','integration','API request timeout in seconds','{\"required\":true,\"min\":5,\"max\":120}','2025-10-16 09:31:42','admin','2025-10-12 00:09:58'),(23,'debug_mode','true','boolean','advanced','Enable debug mode for development','[]','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(24,'log_errors','true','boolean','advanced','Enable error logging','[]','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(25,'show_errors','true','boolean','advanced','Show errors in development mode','[]','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(26,'session_timeout_seconds','3600','integer','advanced','Session timeout seconds','{\"required\":true,\"min\":300,\"max\":86400}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(27,'max_login_attempts','5','integer','advanced','Max login attempts','{\"required\":true,\"min\":3,\"max\":10}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(28,'login_lockout_minutes','15','integer','advanced','Login lockout minutes','{\"required\":true,\"min\":5,\"max\":60}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(29,'password_min_length','8','integer','advanced','Password min length','{\"required\":true,\"min\":6,\"max\":32}','2025-10-24 19:38:18','admin','2025-10-12 00:09:58'),(30,'max_sync_records','1000','integer','advanced','Max sync records','{\"required\":true,\"min\":100,\"max\":10000}','2025-10-16 09:31:42','admin','2025-10-12 00:09:58'),(31,'api_rate_limit','100','integer','advanced','Api rate limit','{\"required\":true,\"min\":10,\"max\":1000}','2025-10-16 09:31:42','admin','2025-10-12 00:09:58'),(56,'qr_code_size','200','integer','qr_code','Qr code size','{\"required\":true,\"min\":100,\"max\":500}','2025-10-13 15:44:27','admin','2025-10-12 00:29:17'),(57,'qr_code_margin','10','integer','qr_code','Qr code margin','{\"required\":true,\"min\":0,\"max\":50}','2025-10-13 15:44:27','admin','2025-10-12 00:29:17'),(58,'max_file_size_mb','5','integer','file_upload','Max file size mb','{\"required\":true,\"min\":1,\"max\":100}','2025-10-13 15:44:27','admin','2025-10-12 00:29:17'),(59,'smtp_host','smtp.gmail.com','string','email','Smtp host','[]','2025-10-13 15:44:27','admin','2025-10-12 00:29:17'),(60,'smtp_port','587','integer','email','Smtp port','[]','2025-10-13 15:44:27','admin','2025-10-12 00:29:17'),(61,'smtp_from_email','noreply@example.com','email','email','Smtp from email','[]','2025-10-13 15:44:27','admin','2025-10-12 00:29:17'),(62,'smtp_from_name','QR Attendance System','string','email','Smtp from name','[]','2025-10-13 15:44:27','admin','2025-10-12 00:29:17'),(96,'qr_code_path','assets/img/qr_codes/','string','qr_code','Directory to store QR code images','[]','2025-10-13 15:44:27','admin','2025-10-13 08:03:02'),(98,'allowed_extensions','csv,json,xlsx','string','file_upload','Comma-separated list of allowed file extensions','[]','2025-10-13 15:44:27','admin','2025-10-13 08:03:02'),(101,'smtp_username','','string','email','SMTP authentication username','[]','2025-10-13 15:44:27','admin','2025-10-13 08:03:02'),(102,'smtp_password','','string','email','SMTP authentication password','[]','2025-10-13 15:44:27','admin','2025-10-13 08:03:02'),(1725,'globalSearchInput','','string','general','System setting','[]','2025-10-24 19:38:18','admin','2025-10-15 21:16:01'),(1726,'searchAll','all','string','general','System setting','[]','2025-10-24 19:38:18','admin','2025-10-15 21:16:01'),(1727,'searchStudents','students','string','general','System setting','[]','2025-10-24 19:38:18','admin','2025-10-15 21:16:01'),(1728,'searchPrograms','programs','string','general','System setting','[]','2025-10-24 19:38:18','admin','2025-10-15 21:16:01'),(1729,'searchAttendance','attendance','string','general','System setting','[]','2025-10-24 19:38:18','admin','2025-10-15 21:16:01'),(1730,'api_endpoint_students','/api/students_sync.php','string','integration','Students sync API endpoint','[]','2025-10-18 12:49:15','admin','2025-10-18 12:49:15'),(1731,'api_endpoint_settings','/api/settings_sync.php','string','integration','Settings sync API endpoint','[]','2025-10-18 12:49:15','admin','2025-10-18 12:49:15'),(1732,'api_endpoint_settings_api','/api/settings_api.php','string','integration','Settings API endpoint','[]','2025-10-18 12:49:15','admin','2025-10-18 12:49:15'),(1733,'api_endpoint_student_api','/api/student_api_simple.php','string','integration','Student API endpoint','[]','2025-10-18 12:49:15','admin','2025-10-18 12:49:15'),(1734,'api_endpoint_admin_attendance','/admin/api/attendance.php','string','integration','Admin attendance API endpoint','[]','2025-10-18 12:49:15','admin','2025-10-18 12:49:15'),(1735,'api_endpoint_sync','/api/sync_api.php','string','integration','Sync API endpoint','[]','2025-10-18 12:49:15','admin','2025-10-18 12:49:15'),(1736,'enable_auto_absent','true','boolean','general','System setting','[]','2025-10-24 19:38:18','admin','2025-10-23 18:27:14'),(1737,'enable_audit_log','true','boolean','advanced','System setting','[]','2025-10-24 19:38:18','admin','2025-10-23 18:27:14'),(1738,'log_retention_days','30','string','advanced','System setting','[]','2025-10-24 19:38:18','admin','2025-10-23 18:27:14'),(1739,'require_password_change','true','boolean','advanced','System setting','[]','2025-10-24 19:38:18','admin','2025-10-23 18:27:14'),(1740,'backup_frequency','weekly','string','advanced','System setting','[]','2025-10-24 19:38:18','admin','2025-10-23 18:27:14'),(1741,'backup_retention_days','30','string','advanced','System setting','[]','2025-10-24 19:38:18','admin','2025-10-23 18:27:14'),(1742,'morning_checkin_start_period','AM','string','shift_timings','System setting','[]','2025-10-24 19:38:18','admin','2025-10-23 19:10:24'),(1743,'morning_checkin_end_period','AM','string','shift_timings','System setting','[]','2025-10-24 19:38:18','admin','2025-10-23 19:10:24'),(1744,'morning_checkout_start_period','AM','string','shift_timings','System setting','[]','2025-10-24 19:38:18','admin','2025-10-23 19:10:24'),(1745,'morning_checkout_end_period','AM','string','shift_timings','System setting','[]','2025-10-24 19:38:18','admin','2025-10-23 19:10:24'),(1746,'morning_class_end_period','AM','string','shift_timings','System setting','[]','2025-10-24 19:38:18','admin','2025-10-23 19:10:24'),(1747,'evening_checkin_start_period','AM','string','shift_timings','System setting','[]','2025-10-24 19:38:18','admin','2025-10-23 19:10:24'),(1748,'evening_checkin_end_period','PM','string','shift_timings','System setting','[]','2025-10-24 19:38:19','admin','2025-10-23 19:10:24'),(1749,'evening_checkout_start_period','AM','string','shift_timings','System setting','[]','2025-10-24 19:38:19','admin','2025-10-23 19:10:24'),(1750,'evening_checkout_end_period','PM','string','shift_timings','System setting','[]','2025-10-24 19:38:19','admin','2025-10-23 19:10:24'),(1751,'evening_class_end_period','PM','string','shift_timings','System setting','[]','2025-10-24 19:38:19','admin','2025-10-23 19:10:24'),(1752,'max_program_years','4','integer','general','Maximum number of years in program (3 or 4)',NULL,'2025-10-24 19:38:18','admin','2025-10-24 14:53:11');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','student','teacher') NOT NULL DEFAULT 'student',
  `student_id` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_username` (`username`),
  KEY `idx_email` (`email`),
  KEY `idx_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (10,'admin','aniquecodes@gmail.com','$2y$10$uzcDa0cHVM014FnZlgTIGeqg.LKPZHTWJolarBF.F8asMD0dRBHF2','admin',NULL,1,'2025-10-24 19:22:41','2025-10-11 12:02:11','2025-10-24 19:22:41');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `year_progression_log`
--

DROP TABLE IF EXISTS `year_progression_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `year_progression_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` varchar(50) NOT NULL,
  `old_year` int(11) NOT NULL,
  `new_year` int(11) NOT NULL,
  `progression_date` date NOT NULL,
  `progression_type` enum('automatic','manual') DEFAULT 'automatic',
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `updated_by` (`updated_by`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_progression_date` (`progression_date`),
  KEY `idx_progression_student_date` (`student_id`,`progression_date`,`old_year`),
  CONSTRAINT `year_progression_log_ibfk_1` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `year_progression_log`
--

LOCK TABLES `year_progression_log` WRITE;
/*!40000 ALTER TABLE `year_progression_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `year_progression_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `qr_attendance`
--

USE `qr_attendance`;

--
-- Final view structure for view `program_stats`
--

/*!50001 DROP VIEW IF EXISTS `program_stats`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `program_stats` AS select `p`.`id` AS `id`,`p`.`code` AS `code`,`p`.`name` AS `name`,`p`.`is_active` AS `is_active`,count(distinct `s`.`student_id`) AS `total_students`,count(distinct `sec`.`id`) AS `total_sections`,sum(`sec`.`capacity`) AS `total_capacity`,avg(`stats`.`attendance_percentage`) AS `avg_attendance` from (((`programs` `p` left join `sections` `sec` on(`p`.`id` = `sec`.`program_id` and `sec`.`is_active` = 1)) left join `students` `s` on(`s`.`section_id` = `sec`.`id`)) left join `student_stats` `stats` on(`s`.`student_id` = `stats`.`student_id`)) group by `p`.`id`,`p`.`code`,`p`.`name`,`p`.`is_active` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `section_stats`
--

/*!50001 DROP VIEW IF EXISTS `section_stats`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `section_stats` AS select `sec`.`id` AS `id`,`sec`.`section_name` AS `section_name`,`p`.`code` AS `program_code`,`p`.`name` AS `program_name`,`sec`.`year_level` AS `year_level`,`sec`.`shift` AS `shift`,`sec`.`capacity` AS `capacity`,count(`s`.`student_id`) AS `current_students`,round(count(`s`.`student_id`) / `sec`.`capacity` * 100,2) AS `capacity_utilization` from ((`sections` `sec` join `programs` `p` on(`sec`.`program_id` = `p`.`id`)) left join `students` `s` on(`s`.`section_id` = `sec`.`id`)) where `sec`.`is_active` = 1 group by `sec`.`id`,`sec`.`section_name`,`p`.`code`,`p`.`name`,`sec`.`year_level`,`sec`.`shift`,`sec`.`capacity` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `student_stats`
--

/*!50001 DROP VIEW IF EXISTS `student_stats`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `student_stats` AS select `s`.`student_id` AS `student_id`,`s`.`name` AS `name`,`s`.`email` AS `email`,`s`.`phone` AS `phone`,`s`.`program` AS `program`,`s`.`shift` AS `shift`,`s`.`year_level` AS `year_level`,`s`.`section` AS `section`,`p`.`name` AS `program_name`,`sec`.`capacity` AS `capacity`,count(`a`.`id`) AS `total_attendance`,sum(case when `a`.`status` = 'Present' then 1 else 0 end) AS `present_count`,case when count(`a`.`id`) > 0 then round(sum(case when `a`.`status` = 'Present' then 1 else 0 end) / count(`a`.`id`) * 100,2) else 0 end AS `attendance_percentage` from (((`students` `s` left join `programs` `p` on(`s`.`program` = `p`.`code`)) left join `sections` `sec` on(`s`.`section_id` = `sec`.`id`)) left join `attendance` `a` on(`s`.`student_id` = `a`.`student_id`)) group by `s`.`student_id`,`s`.`name`,`s`.`email`,`s`.`phone`,`s`.`program`,`s`.`shift`,`s`.`year_level`,`s`.`section`,`p`.`name`,`sec`.`capacity` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-25  1:10:04
